import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import altair as alt 

# Sets the page layout to wide
st.set_page_config(layout="wide")

st.title('⚽Football League Dashboard🌍')
st.write('Created By Hadi Alwi')
st.subheader('Players Stats')

# Load the football dataset
football_df = pd.read_csv('Football_League.csv')

# Create two multiselect dropdowns, one for players and other for metrics
player_names = football_df['Player Names'].unique()
selected_names = st.multiselect('Select Players:', player_names)

all_metrics = [
    "Mins", "Goals", "xG", "xG Per Avg Match",
    "Shots", "OnTarget", "Shots Per Avg Match",
    "On Target Per Avg Match"
]
selected_metrics = st.multiselect('Select Metrics:', all_metrics)

# Get the selected players' data
if selected_names and selected_metrics:
    filtered_df = football_df[football_df['Player Names'].isin(selected_names)]

    # Create Graphs for selected players and metrics
    for i in range(0, len(selected_metrics), 3):
        fig, axs = plt.subplots(1, min(3, len(selected_metrics) - i), figsize=(20, 5))
        for j, metric in enumerate(selected_metrics[i:i + 3]):
            if i + j < len(selected_metrics):
                for player_name, player_data in filtered_df.groupby('Player Names'):
                    player_mean = player_data[metric].mean()
                    axs[j].bar(player_name, player_mean, label=f"{player_name}: {player_mean:.2f}")
                    axs[j].set_title(metric)
                    axs[j].legend()
        st.pyplot(fig)

    # Display the data table
    st.write('## Selected Player Metrics Data')
    st.write(filtered_df.style.set_properties(**{'width': '100%'}).format("{:.2f}", subset=pd.IndexSlice[:, selected_metrics]))

col1, col2, col3 = st.columns([0.3, 0.3, 0.3])

with col1:
    st.subheader('Total Goals by Country')
    selected_countries = st.multiselect('Select Countries:', football_df['Country'].unique())

    # Filter the dataframe based on selected countries
    filtered_df = football_df[football_df['Country'].isin(selected_countries)]

    # Calculate total goals by country
    goals_by_country = filtered_df.groupby('Country')['Goals'].sum()

    # Create a pie chart
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.pie(goals_by_country, labels=goals_by_country.index, autopct='%1.1f%%', startangle=140)
    ax.set_title('Total Goals by Country')
    ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

    # Display the pie chart using st.pyplot
    st.pyplot(fig)
    
with col2:
    st.subheader('Total Goals by League')
    selected_Leagues = st.multiselect('Select Leagues:', football_df['League'].unique())

    # Filter the dataframe based on selected Leagues
    filtered_df = football_df[football_df['League'].isin(selected_Leagues)]

    # Calculate total goals by Leagues
    goals_by_Leagues = filtered_df.groupby('League')['Goals'].sum()

    # Create a pie chart
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.pie(goals_by_Leagues, labels=goals_by_Leagues.index, autopct='%1.1f%%', startangle=140)
    ax.set_title('Total Goals by League')
    ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

    # Display the pie chart using st.pyplot
    st.pyplot(fig)

with col3:
    st.subheader('Top 10 Goalscorers')
    top_scorers = football_df.sort_values(by='Goals', ascending=False).head(10)

    # Multiselect for player selection
    selected_players = st.multiselect(
        "Select Players",
        options=football_df['Player Names'].unique()
    )

    # Filter DataFrame based on selected players
    filtered_df = football_df[football_df['Player Names'].isin(selected_players)]

    # Sort DataFrame by goals in descending order
    top_scorers = filtered_df.sort_values(by='Goals', ascending=False).head(10)

    # Check if there is data to create a heatmap
    if not top_scorers.empty:
        # Pivot the DataFrame for heatmap
        heatmap_data = top_scorers.pivot_table(values='Goals', index='Player Names', columns='League', fill_value=0)

        # Create a heatmap using seaborn
        plt.figure(figsize=(10, 8))
        sns.heatmap(heatmap_data, annot=True, cmap='seismic', fmt='g', linewidths=.7)
        plt.title('Top 10 Goalscorers')
        plt.xlabel('League')
        plt.ylabel('Player')
        plt.xticks(rotation=45, ha='right')

        # Display the heatmap using st.pyplot
        st.pyplot(plt.gcf())
    else:
        st.warning("No data available for the selected players.")

col1, col2, col3 = st.columns([0.3, 0.3, 0.3])

with col1:

    # Filter by player name
    selected_player = st.text_input('Enter Player Name:', '')

    # Filter by metrics using checkboxes
    selected_metrics = st.checkbox('Shots')
    if selected_metrics:
        selected_shots = st.slider('Select Shots Range:', min_value=0, max_value=100, value=(0, 100))
    else:
        selected_shots = (0, 100)

    selected_metrics = st.checkbox('OnTarget')
    if selected_metrics:
        selected_on_target = st.slider('Select OnTarget Range:', min_value=0, max_value=100, value=(0, 100))
    else:
        selected_on_target = (0, 100)

    selected_metrics = st.checkbox('Shots Per Avg Match')
    if selected_metrics:
        selected_shots_per_avg_match = st.slider('Select Shots Per Avg Match Range:', min_value=0, max_value=20, value=(0, 20))
    else:
        selected_shots_per_avg_match = (0, 20)

    selected_metrics = st.checkbox('On Target Per Avg Match')
    if selected_metrics:
        selected_on_target_per_avg_match = st.slider('Select On Target Per Avg Match Range:', min_value=0, max_value=20, value=(0, 20))
    else:
        selected_on_target_per_avg_match = (0, 20)

    # Filter DataFrame based on selected player and metrics
    filtered_df = football_df[
        (football_df['Player Names'].str.contains(selected_player, case=False)) &
        (football_df['Shots'].between(*selected_shots)) &
        (football_df['OnTarget'].between(*selected_on_target)) &
        (football_df['Shots Per Avg Match'].between(*selected_shots_per_avg_match)) &
        (football_df['On Target Per Avg Match'].between(*selected_on_target_per_avg_match))
    ]

    # Create a chart
    if not filtered_df.empty:
        fig, ax = plt.subplots(figsize=(10, 6))

        for metric in ['Shots', 'OnTarget', 'Shots Per Avg Match', 'On Target Per Avg Match']:
            ax.plot(filtered_df[metric], label=f"{selected_player}: {metric}")

        ax.set_xlabel('Matches')
        ax.set_ylabel('Metric Values')
        ax.set_title('Player Metrics Chart')
        ax.legend()

        st.pyplot(fig)
    else:
        st.warning('No data available for the selected filters.')